/*
SQLyog Community Edition- MySQL GUI v7.01 
MySQL - 5.0.27-community-nt : Database - eventapp
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`eventapp` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `eventapp`;

/*Table structure for table `addnotice` */

DROP TABLE IF EXISTS `addnotice`;

CREATE TABLE `addnotice` (
  `id` int(255) NOT NULL auto_increment,
  `notice` longtext,
  `title` varchar(255) default NULL,
  `category` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `addnotice` */

insert  into `addnotice`(`id`,`notice`,`title`,`category`) values (1,'fjfks','sjaifassifi','Culuture'),(2,'fjfks urufuf jfufuff dhdhd dhdbdhd dbdhdhd dvdhdhdhd dhdhdjflgkf gkgkcjf fjfjjfkfb','sjaifass ififudud','NSS');

/*Table structure for table `imgvideo` */

DROP TABLE IF EXISTS `imgvideo`;

CREATE TABLE `imgvideo` (
  `id` int(255) NOT NULL auto_increment,
  `filename` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  `category` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `imgvideo` */

insert  into `imgvideo`(`id`,`filename`,`title`,`category`) values (1,'static/imgvideo/VID-20230411-WA0040.mp4','jcjf','Culuture'),(2,'static/imgvideo/a-20230414-135312.jpg','jcjfudud','NSS'),(5,'static/imgvideo/VID-20230409-WA0020.mp4','jcjfududjdjyy','NSS');

/*Table structure for table `register` */

DROP TABLE IF EXISTS `register`;

CREATE TABLE `register` (
  `id` int(255) NOT NULL auto_increment,
  `username` varchar(255) NOT NULL default '',
  `email` varchar(255) NOT NULL default '',
  `mobile` varchar(255) NOT NULL default '',
  `password` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `register` */

insert  into `register`(`id`,`username`,`email`,`mobile`,`password`) values (1,'a','yashsalvi1999@gmail.com','1234567890','a');

/*Table structure for table `schedule` */

DROP TABLE IF EXISTS `schedule`;

CREATE TABLE `schedule` (
  `id` int(255) NOT NULL auto_increment,
  `filename` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  `category` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `schedule` */

insert  into `schedule`(`id`,`filename`,`title`,`category`) values (1,'static/schedule/a-20230414-135916.jpg','jxjci','NSS'),(2,'static/schedule/a-20230414-135945.jpg','jxjci','Culuture'),(3,'static/schedule/a-20230414-140032.jpg','jxjciyxyxu','Culuture'),(4,'static/schedule/a-20230414-140058.jpg','jxjciyx','Sports');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
