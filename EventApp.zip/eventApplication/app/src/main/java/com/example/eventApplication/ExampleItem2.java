package com.example.eventApplication;
import android.graphics.Bitmap;

public class ExampleItem2 {
    private String mText1;
    private String mText2;

    public ExampleItem2(String text1, String text2) {
        this.mText1 = text1;
        this.mText2 = text2;
    }

    public String getText1() {
        return this.mText1;
    }
    public String getText2() {
        return this.mText2;
    }


}