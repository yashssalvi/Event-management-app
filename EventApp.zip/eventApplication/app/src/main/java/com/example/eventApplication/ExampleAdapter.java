package com.example.eventApplication;

import static com.example.eventApplication.login.session;

import android.content.Context;
import android.content.Intent;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;


public class ExampleAdapter extends RecyclerView.Adapter<ExampleAdapter.ExampleViewHolder> {
    private List<ExampleItem> exampleList;
    private List<ExampleItem> exampleListFull;
    private Context mContext;

    class ExampleViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textView1,Enroll;
        LinearLayout parentLayout;

        ExampleViewHolder(View itemView) {
            super(itemView);

            this.imageView = (ImageView) itemView.findViewById(R.id.image_app);
            this.textView1 = (TextView) itemView.findViewById(R.id.textview1);
            this.Enroll = (TextView) itemView.findViewById(R.id.enroll);
            this.parentLayout = (LinearLayout) itemView.findViewById(R.id.container);

        }
    }

    public ExampleAdapter(List<ExampleItem> exampleList2, Context context) {
       // this.mContext = context;
        this.exampleList = exampleList2;
        this.exampleListFull = new ArrayList(exampleList2);
    }

    public ExampleViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
       // mContext = parent.getContext();
        return new ExampleViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_my_apps, parent, false));
    }
    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        this.mContext = recyclerView.getContext();
    }
    
    public void onBindViewHolder(ExampleViewHolder holder, int position) {

        final ExampleItem currentItem = (ExampleItem) this.exampleList.get(position);
        holder.imageView.setImageBitmap(currentItem.getmImageResource());
        holder.textView1.setText(currentItem.getText1());
        holder.Enroll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
                String url = UrlLinks.checkEnroll;

                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(3);

                nameValuePairs.add(new BasicNameValuePair("username", session));
                nameValuePairs.add(new BasicNameValuePair("title", currentItem.getText1()));
                nameValuePairs.add(new BasicNameValuePair("category", currentItem.getText2()));

                String result = null;
                try {
                    result = jSOnClassforData.forCallingStringAndreturnSTring(url,nameValuePairs);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (result.equals("success")) {
                    Intent io = new Intent(mContext, enrollForm.class);
                    io.putExtra("username",session);
                    io.putExtra("title",currentItem.getText1());
                    io.putExtra("category",currentItem.getText2());
                    mContext.startActivity(io);
                } else {
                    Snackbar.make(view, "Your response is already submitted.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
            }
        });
    }

    public int getItemCount() {
        return this.exampleList.size();
    }

    /* access modifiers changed from: 0000 */
    public void setFilter(List<ExampleItem> filterdNames) {
        this.exampleList = filterdNames;
        notifyDataSetChanged();
    }
}