package com.example.eventApplication.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.eventApplication.R;
import com.example.eventApplication.databinding.FragmentHomeBinding;
import com.example.eventApplication.viewCultureImgvideo;
import com.example.eventApplication.viewCultureNotice;
import com.example.eventApplication.viewCultureSchedule;

public class HomeFragment extends Fragment {
    TextView tx1,tx2,tx3;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = FragmentHomeBinding.inflate(inflater, container, false).getRoot();

        tx1 = root.findViewById(R.id.scedule);
        tx2 = root.findViewById(R.id.notice);
        tx3 = root.findViewById(R.id.imgdata);

        tx1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent io = new Intent(getActivity(), viewCultureSchedule.class);
                startActivity(io);
            }
        });

        tx2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent io = new Intent(getActivity(), viewCultureNotice.class);
                startActivity(io);
            }
        });

        tx3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent io = new Intent(getActivity(), viewCultureImgvideo.class);
                startActivity(io);
            }
        });

        return root;
    }

}