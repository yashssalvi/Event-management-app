package com.example.eventApplication;

public class UrlLinks {
    public static String urlserver="";

    public static String urlserverpython="http://192.168.0.103:5000/";
    public static String registrationurl=urlserver+"registerUser";

    public static String pyregister=urlserverpython+"userRegister";
    public static String pylogin=urlserverpython+"userLogin";

    public static String uploadimg=urlserverpython+"uploadimg";
    public static String uploadSchedule=urlserverpython+"uploadSchedule";
    public static String addNotice=urlserverpython+"addNotice";
    public static String getVideo=urlserverpython+"getVideo";
    public static String uploadimg1=urlserverpython+"uploadimg1";
    public static String calledfunction=urlserverpython+"calledfunction";
    public static String uploadimgandvideo=urlserverpython+"uploadimgandvideo";

    public static String viewCultureScedule=urlserverpython+"viewScedule";
    public static String viewCultureImgVid=urlserverpython+"viewCultureImgVid";
    public static String viewCultureNotice=urlserverpython+"viewCultureNotice";

    public static String checkEnroll=urlserverpython+"checkEnroll";
    public static String Enroll=urlserverpython+"Enroll";

    public static String getEnrolledData=urlserverpython+"getEnrolledData";
    public static String deleteData=urlserverpython+"deleteData";

}
