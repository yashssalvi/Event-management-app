package com.example.eventApplication.ui.gallery;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.eventApplication.R;
import com.example.eventApplication.databinding.FragmentGalleryBinding;
import com.example.eventApplication.viewCultureImgvideo;
import com.example.eventApplication.viewCultureSchedule;
import com.example.eventApplication.viewNssImgvideo;
import com.example.eventApplication.viewNssNotice;
import com.example.eventApplication.viewNssSchedule;

public class GalleryFragment extends Fragment {
    TextView tx1,tx2,tx3;
    private FragmentGalleryBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentGalleryBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        tx1 = root.findViewById(R.id.scedule);
        tx2 = root.findViewById(R.id.notice);
        tx3 = root.findViewById(R.id.imgdata);

        tx1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent io = new Intent(getActivity(), viewNssSchedule.class);
                startActivity(io);
            }
        });

        tx2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent io = new Intent(getActivity(), viewNssNotice.class);
                startActivity(io);
            }
        });

        tx3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent io = new Intent(getActivity(), viewNssImgvideo.class);
                startActivity(io);
            }
        });


        return root;
    }
}