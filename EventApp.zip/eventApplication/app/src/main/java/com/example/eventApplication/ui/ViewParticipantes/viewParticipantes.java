package com.example.eventApplication.ui.ViewParticipantes;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.example.eventApplication.ExampleItem;
import com.example.eventApplication.R;
import com.example.eventApplication.UrlLinks;
import com.example.eventApplication.jSOnClassforData;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class viewParticipantes extends Fragment {
    @SuppressLint("ResourceAsColor")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_view_participantes, container, false);

        @SuppressLint({"MissingInflatedId", "LocalSuppress"})
        TableLayout tableLayout = root.findViewById(R.id.table_layout);

        TableRow headerRow = new TableRow(getActivity());
        TextView header1 = new TextView(getActivity());
        header1.setText("Full name");
        header1.setPadding(50, 50, 50, 50);
        header1.setTextColor(Color.BLACK);
        header1.setTextSize(22);
        header1.setTypeface(null, Typeface.BOLD);
        headerRow.addView(header1);

        TextView header2 = new TextView(getActivity());
        header2.setText("Email");
        header2.setPadding(50, 50, 50, 50);
        header2.setTextColor(Color.BLACK);
        header2.setTextSize(22);
        header2.setTypeface(null, Typeface.BOLD);
        headerRow.addView(header2);

        TextView header3= new TextView(getActivity());
        header3.setText("Mobile");
        header3.setPadding(50, 50, 50, 50);
        header3.setTextColor(Color.BLACK);
        header3.setTextSize(22);
        header3.setTypeface(null, Typeface.BOLD);
        headerRow.addView(header3);

        TextView header4 = new TextView(getActivity());
        header4.setText("Branch");
        header4.setPadding(50, 50, 50, 50);
        header4.setTextColor(Color.BLACK);
        header4.setTextSize(22);
        header4.setTypeface(null, Typeface.BOLD);
        headerRow.addView(header4);

        TextView header5 = new TextView(getActivity());
        header5.setText("Year");
        header5.setPadding(50, 50, 50, 50);
        header5.setTextColor(Color.BLACK);
        header5.setTextSize(22);
        header5.setTypeface(null, Typeface.BOLD);
        headerRow.addView(header5);

        TextView header6 = new TextView(getActivity());
        header6.setText("Title");
        header6.setPadding(50, 50, 50, 50);
        header6.setTextColor(Color.BLACK);
        header6.setTextSize(22);
        header6.setTypeface(null, Typeface.BOLD);
        headerRow.addView(header6);

        TextView header7 = new TextView(getActivity());
        header7.setText("Category");
        header7.setPadding(50, 50, 50, 50);
        header7.setTextColor(Color.BLACK);
        header7.setTextSize(22);
        header7.setTypeface(null, Typeface.BOLD);
        headerRow.addView(header7);
        tableLayout.addView(headerRow);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        String url = UrlLinks.getEnrolledData;
        List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);

        String result = null;
        try {
            result = jSOnClassforData.forCallingStringAndreturnSTring(url, nameValuePairs);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            JSONArray jsonArray = new JSONArray(result);
            for (int i = 0; i < jsonArray.length(); i++) {

                TableRow row1 = new TableRow(getActivity());

                TextView data11 = new TextView(getActivity());
                data11.setText(String.valueOf(jsonArray.getJSONArray(i).getString(2)));
                data11.setPadding(50, 35, 50, 35);
                data11.setTextColor(Color.BLACK);
                data11.setTextSize(20);
                row1.addView(data11);

                TextView data12 = new TextView(getActivity());
                data12.setText(String.valueOf(jsonArray.getJSONArray(i).getString(3)));
                data12.setPadding(50, 35, 50, 35);
                data12.setTextColor(Color.BLACK);
                data12.setTextSize(20);
                row1.addView(data12);

                TextView data13 = new TextView(getActivity());
                data13.setText(String.valueOf(jsonArray.getJSONArray(i).getString(4)));
                data13.setPadding(50, 35, 50, 35);
                data13.setTextColor(Color.BLACK);
                data13.setTextSize(20);
                row1.addView(data13);

                TextView data14 = new TextView(getActivity());
                data14.setText(String.valueOf(jsonArray.getJSONArray(i).getString(5)));
                data14.setPadding(50, 35, 50, 35);
                data14.setTextColor(Color.BLACK);
                data14.setTextSize(20);
                row1.addView(data14);

                TextView data15 = new TextView(getActivity());
                data15.setText(String.valueOf(jsonArray.getJSONArray(i).getString(6)));
                data15.setPadding(50, 35, 50, 35);
                data15.setTextColor(Color.BLACK);
                data15.setTextSize(20);
                row1.addView(data15);

                TextView data16 = new TextView(getActivity());
                data16.setText(String.valueOf(jsonArray.getJSONArray(i).getString(8)));
                data16.setPadding(50, 35, 50, 35);
                data16.setTextColor(Color.BLACK);
                data16.setTextSize(20);
                row1.addView(data16);

                TextView data17 = new TextView(getActivity());
                data17.setText(String.valueOf(jsonArray.getJSONArray(i).getString(9)));
                data17.setPadding(50, 35, 50, 35);
                data17.setTextColor(Color.BLACK);
                data17.setTextSize(20);
                row1.addView(data17);

                tableLayout.addView(row1);

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

//// Create data rows
//        TableRow row1 = new TableRow(getActivity());
//        TextView data11 = new TextView(getActivity());
//        data11.setText("Row 1, Column 1");
//        data11.setPadding(5, 5, 5, 5);
//        row1.addView(data11);
//        TextView data12 = new TextView(getActivity());
//        data12.setText("Row 1, Column 2");
//        data12.setPadding(5, 5, 5, 5);
//        row1.addView(data12);
//        tableLayout.addView(row1);

        return root;
    }
}