package com.example.eventApplication;
import android.graphics.Bitmap;
public class ExampleItem {
    private Bitmap mImageResource;
    private String mText1;
    private String mText2;

    public ExampleItem(Bitmap imageResource, String text1, String text2) {
        this.mImageResource = imageResource;
        this.mText1 = text1;
        this.mText2 = text2;
    }

    public Bitmap getmImageResource() {
        return mImageResource;
    }

    public void setmImageResource(Bitmap mImageResource) {
        this.mImageResource = mImageResource;
    }

    public String getText1() {
        return this.mText1;
    }

    public String getText2() {
        return this.mText2;
    }


}