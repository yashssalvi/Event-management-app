package com.example.eventApplication.ui;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.eventApplication.R;
import com.example.eventApplication.UrlLinks;
import com.example.eventApplication.jSOnClassforData;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

public class addNotice extends Fragment {
    Spinner spin1;
    TextInputLayout title,notice;
    EditText ed1,ed2;
    TextView add;
    String[] listnumber;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_add_notice, container, false);

        listnumber = getResources().getStringArray(R.array.category);
        spin1 = root.findViewById(R.id.auto);
        add = root.findViewById(R.id.addnotice);
        notice = root.findViewById(R.id.notice);
        ed1 = notice.getEditText();
        title = root.findViewById(R.id.title);
        ed2 = title.getEditText();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), R.layout.dropdown_item, listnumber);
        spin1.setAdapter(adapter);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String notice = ed1.getText().toString();
                String title = ed2.getText().toString();
                String category = spin1.getSelectedItem().toString();

                if(notice.equals("") || category.equals("Select category") || title.equals("")){
                    Snackbar.make(v, "Please fill details.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else {

                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                    String url = UrlLinks.addNotice;

                    List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(3);

                    nameValuePairs.add(new BasicNameValuePair("notice", notice));
                    nameValuePairs.add(new BasicNameValuePair("title", title));
                    nameValuePairs.add(new BasicNameValuePair("category", category));

                    String result = null;
                    try {
                        result = jSOnClassforData.forCallingStringAndreturnSTring(url, nameValuePairs);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if (result.equals("success")) {
                        Snackbar.make(v, "Notice Added.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                    } else {
                        Snackbar.make(v, "Something went wrong.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                    }
                }
            }
        });

        return root;
    }
}